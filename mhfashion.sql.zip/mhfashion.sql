-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 28 avr. 2021 à 13:29
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mhfashion`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` varchar(8) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `adresse` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `prenom`, `nom`, `adresse`) VALUES
('66666666', 'nizar', 'hajjouni', 'fouchen mhamdia cite ksar'),
('77777777', 'Bertram', 'Raab', 'Greutstr. 166b'),
('88888888', 'mohamed ', 'ali maki', 'cite lanbout fouchena ben arous');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id` varchar(8) NOT NULL,
  `ref` varchar(4) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prixtotal` float NOT NULL,
  `confirmation` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id`, `ref`, `quantite`, `prixtotal`, `confirmation`) VALUES
('66666666', '    ', 12, 1520, 'Confirme'),
('66666666', ' EAT', 150, 1550, 'Confirme'),
('66666666', ' OOO', 0, 1520, 'Confirme'),
('77777777', ' EAT', 15, 1520, 'Occuper'),
('88888888', ' OOO', 11, 1500, 'Enattend');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `ref` varchar(4) NOT NULL,
  `ndp` varchar(150) NOT NULL,
  `coleur` varchar(15) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix` float NOT NULL,
  `taille` varchar(12) NOT NULL,
  `gategorie` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`ref`, `ndp`, `coleur`, `quantite`, `prix`, `taille`, `gategorie`) VALUES
('    ', 'montre', 'noir', 88, 150, 'S', 's'),
(' EAT', 'montre', 'Noir', -5, 150, 'S', 'S'),
(' OOO', 'bior', 'noir', 10, 120, '', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id`,`ref`),
  ADD KEY `fk2` (`ref`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`ref`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`id`) REFERENCES `client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2` FOREIGN KEY (`ref`) REFERENCES `produit` (`ref`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
