<?php

namespace Mpdf\Tag;

class Sub extends InlineTag
{


}
